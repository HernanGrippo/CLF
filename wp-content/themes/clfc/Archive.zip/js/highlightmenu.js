var url = "<?php bloginfo('template_url'); ?>/template-parts/header.php".split("/"); 
var navLinks = document.getElementsByClassName("nav-link");
var i=0;
var currentPage = url[url.length - 1];
for(i;i<navLinks.length;i++){
  var lb = navLinks[i].href.split("/");
  if(lb[lb.length-1] == currentPage) {  
  navLinks[i].className = "current"; 
  }
  console.log(lb[lb.length-1]);
  console.log(currentPage);
  }