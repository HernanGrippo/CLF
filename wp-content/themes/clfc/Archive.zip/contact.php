<?php
/*
Template Name: Contact
*/
?>
<?php get_header();?>
<div class="contactpad">
<? get_template_part( 'components/contactform' ); ?>
</div>
<?php get_footer();?> 