  <!-- CONTACT FORM -->
  <section id="contact-form">
    <div class="row">
      <div class="col">
        <div class="container">
          <div class="left text-center">
            <h2>Get Involved.</h2>
            <p>Sign up for our mailing list.</p>
          </div>
            <div class="right text-center">
                <div class="form">
                   <?php echo apply_shortcodes('[contact-form-7 id="11" title="Contact form 1"]'); ?>
                </div>
                  <img src="https://www.respectconnectprotect.org/wp-content/uploads/2023/04/stone.png" alt="happy stone">
            </div>
          </div> 
        </div>
    </div>
  </section>